# !/usr/bin/env python
# -*- coding:utf-8 -*-
from pms.extensions import db
import datetime

class Log(db.Model):
    """
    日志表对应实体类
    """
    __tablename__ = "t_log"
    
    id = db.Column(db.Integer,primary_key = True) # 主键
    log_type = db.Column(db.String(1024)) # 日志类型
    desc = db.Column(db.String(1024)) # 日志描述
    
    create_time = db.Column(db.DateTime()) # 创建时间
    update_time = db.Column(db.DateTime) # 更新时间
    
    def __repr__(self):
        return "<Log %s:%s>" % (self.log_type,self.desc)


def save_log(log_type,desc):
    """
    保存日志
    """
    log = Log()
    log.log_type = log_type
    log.desc = desc
    log.create_time = datetime.datetime.now()
    log.update_time = datetime.datetime.now()
    try:
        db.session.add(log)
        db.session.commit()
    except:
        db.session.rollback()
        pass
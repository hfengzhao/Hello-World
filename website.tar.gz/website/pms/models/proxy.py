# !/usr/bin/env python
# -*- coding:utf-8 -*-
from pms.extensions import db

class Proxy(db.Model):
    """
    新闻表对应实体类
    """
    __tablename__ = "t_proxy"
    
    id = db.Column(db.Integer,primary_key = True) # 主键
    country = db.Column(db.String(500)) # 国家
    ip_addr = db.Column(db.String(200)) # ip地址
    ip_type = db.Column(db.String(40))  # ip类型
    port = db.Column(db.Integer) # 端口
    proxy_type = db.Column(db.String(30)) # 代理类型
    server_location = db.Column(db.String(300)) # 服务器地址
    is_anonymous = db.Column(db.Boolean) # 是否匿名
    response_speed = db.Column(db.Float) # 响应时间/秒
    alive_time = db.Column(db.Float) # 存活时间/秒
    validate_time = db.Column(db.DateTime) # 验证时间
    create_time = db.Column(db.DateTime()) # 创建时间
    status = db.Column(db.Boolean) # 状态
    fail_count = db.Column(db.Integer) #失败次数
    
    __table_args__ = (db.UniqueConstraint('ip_addr','port'),)
    
    def __repr__(self):
        return "<Proxy %s:%s>" % (self.ip_addr,self.port)
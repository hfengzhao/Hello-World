#!/usr/bn/env python
# -*- coding:utf-8 -*-
import logging
logger = logging.getLogger(__name__)

import os
from flask import Flask,render_template,abort,url_for,redirect
from pms.extensions import db
from pms.views import *


store_path = os.path.abspath(os.path.dirname(__file__))
app = Flask(__name__, instance_path=store_path, instance_relative_config=True)

def config_app(app, config):
	"""
	应用程序配置
	"""
	logger.info('应用程序配置')
	app.config.from_pyfile(config)
	db.init_app(app)
	db.app = app

	@app.after_request
	def after_request(response):
		try:
			db.session.commit()
		except Exception as e:
			print(e)
			db.session.rollback()
			abort(500)
		return response

def dispatch_handlers(app):
	"""
	错误处理
	"""
	d = {}
	d['title'] = u'提示'
	@app.errorhandler(403)
	def permission_error(error):
		d['message'] = u'您无权执行当前操作！请登录或检查url是否错误。'
		return render_tmeplate('error.html', **d), 403

	@app.errorhandler(404)
	def page_not_found(error):
		# d['message'] = u'你访问的页面不存在！'
		return redirect(url_for('proxy.ls',cata = 'anony'))

	@app.errorhandler(500)
	def internal_server_error(error):
		d['message'] = u'你访问的页面出错了，请稍候再试！'
		return render_template('error.html', **d)

def dispatch_apps(app):
	app.register_blueprint(proxy_app, url_prefix='/')

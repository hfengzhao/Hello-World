#coding:utf-8
from flask_apscheduler import APScheduler
from sqlalchemy import or_,and_,func
from concurrent.futures import ThreadPoolExecutor ,wait
from pms.extensions import db
import requests
import datetime
import time
import random
import os
import subprocess
import re
import json
from bs4 import BeautifulSoup
from pms.models import Proxy
from pms.models.log import save_log

scheduler = APScheduler()

# 多线程更新代理信息
UPDATE_HTREAD_POOL = ThreadPoolExecutor(70)
UPDATE_HTREAD_LIST = []

headers = {"User-Agent": "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:70.0) Gecko/20100101 Firefox/70.0"}
def crawl_89ip_proxies():
    """
    爬取89ip代理任务
    """
    
    try:
        for i in range(1,10000):
            resp = requests.get("http://www.89ip.cn/index_%s.html" % i,headers = headers,timeout=5)
            
            doc = BeautifulSoup(resp.text,"html.parser")
            
            if not doc.find("tbody").find("tr"):
                break

            for tr in doc.find("tbody").find_all("tr"):
                tds = tr.find_all("td")
                proxy = Proxy()
                proxy.ip_addr = tds[0].get_text().strip()
                proxy.port = int(tds[1].get_text().strip())
                proxy.is_anonymous = True
                proxy.create_time = datetime.datetime.now()
                proxy.status = True
                proxy.country = "中国"
                proxy.server_location = tds[2].get_text().strip()

                save_proxy(proxy)
                
    except Exception as e:
        save_log("爬取89ip代理",e)


def crawl_freeip_proxies():
    """
    爬取freeip代理
    """
    # 普通代理
    try:
        for i in range(1,10000):
            resp = requests.get("https://www.freeip.top/?page=%s&anonymity=1" % i,headers = headers,timeout=5)
            doc = BeautifulSoup(resp.text,"html.parser")
            if not doc.find("tbody").find("tr"):
                break

            #print(doc.find("tbody"))
            for tr in doc.find("tbody").find_all("tr"):
                tds = tr.find_all("td")
                proxy = Proxy()
                proxy.ip_addr = tds[0].get_text().strip()
                proxy.ip_type = tds[6].get_text().strip() if tds[6].get_text().strip() != "XX" else ""
                proxy.port = int(tds[1].get_text().strip())
                proxy.proxy_type = tds[3].get_text().strip()
                proxy.is_anonymous = False
                proxy.server_location = tds[4].get_text().strip().replace("XX","")
                proxy.status = True
                proxy.create_time = datetime.datetime.now()
                
                save_proxy(proxy)

    except Exception as e:
        save_log("爬取freeip普通代理",e)
    
    # 高匿代理
    try:
        for i in range(1,10000):
            resp = requests.get("https://www.freeip.top/?page=%s&anonymity=2" % i,headers = headers,timeout=5)
            doc = BeautifulSoup(resp.text,"html.parser")
            if not doc.find("tbody").find("tr"):
                break

            for tr in doc.find("tbody").find_all("tr"):
                tds = tr.find_all("td")
                proxy = Proxy()
                proxy.ip_addr = tds[0].get_text().strip()
                proxy.ip_type = tds[6].get_text().strip() if tds[6].get_text().strip() != "XX" else ""
                proxy.port = int(tds[1].get_text().strip())
                proxy.proxy_type = tds[3].get_text().strip()
                proxy.is_anonymous = True
                proxy.server_location = tds[4].get_text().strip().replace("XX","")
                proxy.status = True
                proxy.create_time = datetime.datetime.now()
                
                save_proxy(proxy)
    except Exception as e:
        save_log("爬取freeip高匿代理",e)


def crawl_iphai_proxies():
    """
    爬取ip海代理
    """

    # 国内高匿名代理
    try:
        resp = requests.get("http://www.iphai.com/free/ng",headers = headers,timeout=5)
        doc = BeautifulSoup(resp.text,"html.parser")
        for tr in doc.find("table").find_all("tr"):
            if tr.find("th"):
                continue
            tds = tr.find_all("td")
            proxy = Proxy()
            proxy.ip_addr = tds[0].get_text().strip()
            proxy.port = int(tds[1].get_text().strip())
            proxy.proxy_type = tds[3].get_text().strip()
            proxy.server_location = tds[4].get_text().strip()
            proxy.status = True
            proxy.is_anonymous = True
            proxy.country = "中国"
            proxy.create_time = datetime.datetime.now()

            save_proxy(proxy)

    except Exception as e:
        save_log("爬取ip海国内高匿名代理",e)
        
    # 国内普通代理
    try:
        resp = requests.get("http://www.iphai.com/free/np",headers = headers,timeout=5)
        doc = BeautifulSoup(resp.text,"html.parser")
        for tr in doc.find("table").find_all("tr"):
            if tr.find("th"):
                continue
            tds = tr.find_all("td")
            proxy = Proxy()
            proxy.ip_addr = tds[0].get_text().strip()
            proxy.port = int(tds[1].get_text().strip())
            proxy.proxy_type = tds[3].get_text().strip()
            proxy.server_location = tds[4].get_text().strip()
            proxy.status = True
            proxy.is_anonymous = False
            proxy.country = "中国"
            proxy.create_time = datetime.datetime.now()
            
            save_proxy(proxy)

    except Exception as e:
        save_log("爬取ip海国内普通代理",e)

    # 国外高匿名代理
    try:
        resp = requests.get("http://www.iphai.com/free/wg",headers = headers,timeout=5)
        doc = BeautifulSoup(resp.text,"html.parser")
        for tr in doc.find("table").find_all("tr"):
            if tr.find("th"):
                continue
            tds = tr.find_all("td")
            proxy = Proxy()
            proxy.ip_addr = tds[0].get_text().strip()
            proxy.port = int(tds[1].get_text().strip())
            proxy.proxy_type = tds[3].get_text().strip()
            proxy.server_location = tds[4].get_text().strip().replace("X","")
            proxy.status = True
            proxy.is_anonymous = True
            proxy.create_time = datetime.datetime.now()
            
            save_proxy(proxy)

    except Exception as e:
        save_log("爬取ip海国外高匿代理",e)
    # 国外普通代理
    try:
        resp = requests.get("http://www.iphai.com/free/wp",headers = headers,timeout=5)
        doc = BeautifulSoup(resp.text,"html.parser")
        for tr in doc.find("table").find_all("tr"):
            if tr.find("th"):
                continue
            tds = tr.find_all("td")
            proxy = Proxy()
            proxy.ip_addr = tds[0].get_text().strip()
            proxy.port = int(tds[1].get_text().strip())
            proxy.proxy_type = tds[3].get_text().strip()
            proxy.server_location = tds[4].get_text().strip().replace("X","")
            proxy.status = True
            proxy.is_anonymous = False
            proxy.create_time = datetime.datetime.now()
            
            save_proxy(proxy)

    except Exception as e:
        save_log("爬取ip海国外普通代理",e)
    
def crawl_freeproxy_proxies():
    """
    爬取freeproxy代理
    """
    try:
        for i in range(1,3000):
            resp = requests.get("https://free-proxy-list.com/?page=%s" % i,headers = headers,timeout=50)
            doc = BeautifulSoup(resp.text,"html.parser")
            if not doc.find("table",{"class":"proxy-list"}).find("tbody").find("tr"):
                break

            for tr in doc.find("table",{"class":"proxy-list"}).find("tbody").find_all("tr"):
                tds = tr.find_all("td")
                proxy = Proxy()
                proxy.ip_addr = tds[0].get_text().strip()
                proxy.port = int(tds[1].get_text().strip())
                proxy.country = tds[2].get_text().strip()
                proxy.create_time = datetime.datetime.now()
                proxy.is_anonymous = True if "Anonymous" in tds[8].get_text().strip() else False
                proxy.server_location = tds[3].get_text().strip()
                proxy.status = True
                proxy.proxy_type = tds[7].get_text().strip()

                save_proxy(proxy)

    except Exception as e:
        save_log("爬取freeproxy代理",e)            


def crawl_daily_proxies():
    """
    爬取每日代理ip
    """
    try:
        resp = requests.get("https://www.proxylistdaily.net/",headers = headers,timeout=50)
        doc = BeautifulSoup(resp.text,"html.parser")
        for div in doc.find_all("div",{"class":"centeredProxyList"}):
            for proxy in div.get_text().split("\n"):
                if "IP" in proxy:
                    continue

                p = Proxy()
                p.ip_addr = proxy.split(":")[0]
                p.port = proxy.split(":")[1]
                p.status = True
                p.create_time = datetime.datetime.now()

                save_proxy(p)
    except Exception as e:
        save_log("daily proxy爬虫",e)


def update_ip_location():
    """
    根新未知ip地址的地理位置
    """
    proxys = db.session.query(Proxy).filter(or_(Proxy.country == "",Proxy.server_location == "",Proxy.country == None,Proxy.server_location == None)).limit(2000).all()
    if not proxys or len(proxys) == 0:
        return

    for p in proxys:
        try:
            resp = requests.get("http://ip-api.com/json/%s?lang=zh-CN" % p.ip_addr,headers = headers)
            dic = json.loads(resp.text)
            country = dic.get("country","")
            region = dic.get("regionName","")
            server_location = dic.get("city","")

            p.country = country
            p.server_location = "%s/%s" % (server_location,region) if not p.server_location else p.server_location
            
            db.session.commit()
        except Exception as e:
            save_log("修改ip位置报错：",e)


def update_proxy_info():
    """
    更新代理信息
    """
    
    proxys = db.session.query(Proxy).filter(or_(Proxy.validate_time == '',Proxy.validate_time == None,Proxy.response_speed == "",Proxy.response_speed == None,Proxy.validate_time <= datetime.datetime.now() - datetime.timedelta(minutes=720))).all()
    
    if not proxys or len(proxys) == 0:
        return

    global UPDATE_HTREAD_LIST

    for pro in proxys:
        UPDATE_HTREAD_LIST.append(UPDATE_HTREAD_POOL.submit(test_proxy,pro))

    wait(UPDATE_HTREAD_LIST)
    UPDATE_HTREAD_LIST = []

def test_proxy(pro):
    """
    测试代理响应速度
    """
    try:
        pro = db.session.query(Proxy).filter(Proxy.id == pro.id).first()
        # 如果失败次数超过8次，删除记录
        if pro.fail_count is not None and pro.fail_count >= 8:
            db.session.query(Proxy).filter(Proxy.id == pro.id).delete()
            db.session.commit()
            return

        # http协议测试
        resp = subprocess.getstatusoutput(r'curl --connect-timeout 10 -w %{time_total} -x ' + pro.ip_addr + ":" + str(pro.port) + r' https://pv.sohu.com/cityjson 2>/dev/null' )
        # print("\n\n",resp,"\n\n")

        ishttpproxy = False

        if resp[0] == 0:
            ishttpproxy = True
        
        try:
            http_response_speed = re.findall(r".*(\d+\.\d{6}).*",resp[1])[0]
        except:
            pass

        # https协议测试
        resp = subprocess.getstatusoutput(r'curl --connect-timeout 10 -w %{time_total} -x ' + pro.ip_addr + ":" + str(pro.port) + r' https://icanhazip.com/ 2>/dev/null')

        result = resp[1].split("\n")
        # print('curl --connect-timeout 40 -w %{time_total} -x ' + pro.ip_addr + ":" + str(pro.port) + r' https://icanhazip.com/ 2>/dev/null')
        # print(resp)

        # 如果https测试成功设定为https，更新响应速度
        if resp[0] == 0 and result[0] == pro.ip_addr:
            pro.status = True
            pro.response_speed = result[1]
            pro.fail_count = 0
        else:
            pro.proxy_type = "HTTPS"
            pro.status = False
            pro.response_speed = None

            if ishttpproxy:
                pro.fail_count = 0
                pro.proxy_type = "HTTP"
                pro.status = True
                pro.response_speed = http_response_speed
        
        if not pro.status:
            if not pro.fail_count:
                pro.fail_count = 1
            else:
                pro.fail_count += 1

        pro.validate_time = datetime.datetime.now()
        print(pro.validate_time)
        db.session.commit()
    except Exception as e:
        save_log("更新代理信息",e)
        db.session.rollback()

def save_proxy(proxy):
    """
    保存代理
    """
    try:
        regex = re.compile(r"[^\u4e00-\u9fa5\w\s\d\u3002\uff1b\uff0c\uff1a\u201c\u201d\uff08\uff09\u3001\uff1f\u300a\u300b\-\.!@#\$%\\\^&\*\)\(\+=\{\}\[\]\\/\",'<>~`\?:;\|]")
        proxy.server_location = re.sub(regex,"",proxy.server_location)
        db.session.add(proxy)
        db.session.commit()
        print(proxy)
    except:
        db.session.rollback()
        pass

# crawl_proxies()


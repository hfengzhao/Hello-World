# !/usr/bin/env python
# -*- coding:utf-8 -*-

from flask import Blueprint, request, abort, render_template, jsonify, redirect, url_for, jsonify
from pms.extensions import db
from pms.models import Proxy
from flask_sqlalchemy import Pagination

proxy_app = Blueprint("proxy", __name__, url_prefix="/")

@proxy_app.route('/index',methods=['GET'])
def index():
    """
    网站首页
    """
    a_list = db.session.query(Proxy).filter(Proxy.is_anonymous == True).limit(10).all()
    o_list = db.session.query(Proxy).filter(Proxy.is_anonymous == False).limit(10).all()

    return render_template('index.html',anony_list = a_list,ordinary_list = o_list)

@proxy_app.route("/api",methods = ['GET'])
def api():
    """
    获取api接口
    """
    return render_template('api.html')

@proxy_app.route('/api/get',methods = ['POST','GET'])
def get_proxies():
    """
    获取代理列表
    """
    datas = db.session.query(Proxy.ip_addr,Proxy.port).filter(Proxy.response_speed <= 5).limit(20).all()
    return jsonify(datas)


@proxy_app.route('/ls/<cata>/',defaults={"page_no":1},methods = ['GET'])
@proxy_app.route('/ls/<cata>/<int:page_no>',methods = ['GET'])
def ls(cata,page_no):
    """
    查询代理列表
    """
    if cata not in ["anony","ordinary"]:
        return redirect(url_for('proxy.ls',cata='anony'))

    page = {}
    count = db.session.query(Proxy.id).filter(Proxy.is_anonymous == True if "anony" == cata else False).count()
    total_page = int((count - 1) / 20) + 1
    page["total_page"] = total_page
    
    if page_no >= total_page:
        page_no = total_page
    elif page_no < 1:
        page_no = 1

    page["page_no"] = page_no

    query = db.session.query(Proxy.id,Proxy.ip_addr,Proxy.port,Proxy.is_anonymous,Proxy.country,Proxy.server_location,Proxy.proxy_type,Proxy.response_speed,Proxy.validate_time).filter(Proxy.is_anonymous == True if "anony" == cata else False).offset((page_no - 1) * 20).limit(20)

    return render_template('list.html',proxy_list=query.all(),page=page)


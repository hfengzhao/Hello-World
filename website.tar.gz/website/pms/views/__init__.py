# !/usr/bin/env python
# -*- coding:utf-8 -*-

from .proxyview import proxy_app

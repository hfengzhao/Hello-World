#!/usr/bin/env python
#-*-coding:utf-8-*-
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

import logging
logging.basicConfig(level=logging.INFO)

from flask_script import Manager, Shell
from pms import app, db, config_app, dispatch_handlers, dispatch_apps
from pms.scheduler import scheduler
import pms.models

manager = Manager(app, with_default_commands=False)

def _make_context():
    return dict(app=app, db=db)

manager.add_command('shell', Shell(make_context=_make_context))

@manager.option('-c', '--config', dest='config', help='Configuration file name', default='pms.cfg')
def runserver(config):
    config_app(app, config)
    dispatch_handlers(app)
    dispatch_apps(app)
    scheduler.init_app(app)
    scheduler.start()    
    app.run(host='0.0.0.0')

@manager.option('-c', '--config', dest='config', help='Configuration file name', default='pms.cfg')
def initdb(config='pms.cfg'):
    config_app(app, config)

    try:
        db.drop_all()
        db.create_all()
        print('Create tables success')
    except Exception as e:
        print('Create tables fail:%s' % e)
        sys.exit(0)

if __name__ == '__main__':
	manager.run()
